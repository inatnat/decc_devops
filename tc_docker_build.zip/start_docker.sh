docker run -it --name tcuat -p 8301:8080 -v /Users/inatnat/data/tc6/data/:/usr/local/tomcat/webapps/fileUploads-tc/doc/ -v /Users/inatnat/data/tc6/csv/:/usr/local/tomcat/webspps/fileUploads-tc/doc/ inatnat/tcuat


