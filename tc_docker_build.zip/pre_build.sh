rm -Rf /Users/inatnat/NetBeansProjects/decc_devops/tc6/uat/*.war
cp /Users/inatnat/NetBeansProjects/tc-release6/dist/tc6.war /Users/inatnat/NetBeansProjects/decc_devops/tc6/uat/
cp /Users/inatnat/NetBeansProjects/tc-fileuploads/TCFileUploads/dist/fileUploads-tc.war /Users/inatnat/NetBeansProjects/decc_devops/tc6/uat/
cp /var/decc/tc6/conf/config.properties /Users/inatnat/NetBeansProjects/decc_devops/tc6/uat/
docker stop tcuat
docker rm tcuat

