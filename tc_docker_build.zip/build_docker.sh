docker build -t inatnat/tcuat .

